/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package co.edu.unbosque.reto2.controlador;

/**
 *
 * @author Mcalderon
 */
public class Main {
    public static void main(String[] args) {
        Controlador control;
        control = new Controlador();
    }
        
    }
}
